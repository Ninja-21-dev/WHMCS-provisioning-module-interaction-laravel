<?php
/**
 * loader.php is created by Hadesson
 *
 */
require_once __DIR__ . '/requests/main.php';
