<?php
/**
 * main.php is created by Hadesson
 *
 */

require_once __DIR__ . '/login_request.php';
require_once __DIR__ . '/user_operation_request.php';
require_once __DIR__ . '/team_operation_request.php';
require_once __DIR__ . '/generate_password.php.php';
